<?php


 //$copa = array("1930"=>"Uruguai","1934"=>"Itália","1938"=>"França");
 $copa = ["1930"=>"Uruguai","1934"=>"Itália","1938"=>"França"];
 $copa["1942"] = "Cancelado devido à 2a Guerra Mundial";
 $copa["1946"] = "Cancelado devido à 2a Guerra Mundial";
 $copa["1950"] = "Brasil";
 $copa["1954"] = "Suíça";
 $copa["1958"] = "Suécia";
 $copa["1962"] = "Chile";
 $copa["1966"] = "Inglaterra";
 $copa["1970"] = "México";
 $copa["1974"] = "Alemanha";
 $copa["1978"] = "Argentina";
 $copa["1982"] = "Espanha";
 $copa["1986"] = "México";
 $copa["1990"] = "Itália";
 $copa["1994"] = "Estados Unidos";
 $copa["1998"] = "França";
 $copa["2002"] = "Coréia do Sul / Japão";
 $copa["2006"] = "Alemanha";
 $copa["2010"] = "África do Sul";
 $copa["2014"] = "Brasil";
 $copa["2018"] = "Rússia";

 // copa acontece de 4 em 4 anos.
 // copa iniciou em 1930.
 // copa sempre em ano par.
 // copa nunca em ano multiplo de 4.

if(!empty($_POST)){

    $dataNascimento = $_POST["data_nascimento"];
    //spoiller 1: DateTime é uma Classe de Objetos - veremos o que é isso no semestre.
    $data_nasc = new DateTime($dataNascimento);
    
    /*Função date: retorna a data atual no formato passado entre aspas.
    Principais parâmetros Y - ano; m - mês; d - dia; H - hora(24); i - minuto; s - segundos;
    */
    $data_atual = new DateTime( date('Y-m-d') );
    //spoiller 2: $date é um objeto do tipo DateTime; 
    //spoiller 3: ->diff é um método do objeto DateTime
    $intervalo = $data_nasc->diff( $data_atual ); 
    
    $idade = (int)$intervalo->format('%Y');   

    echo "<h3>Dados Cadastrais:</h3>
          <b>Nome:</b>" . $_POST["nome"] . "<br />
          <b>Email:</b>" . $_POST["email"] . "<br />
          <b>Sexo:</b>" . $_POST["sexo"] . "<br />
          <b>Data Nascimento:</b>" .$_POST["data_nascimento"]. "<br />
          <b>Idade:</b> " . $idade . " anos<br />
          <h3>Copas assistidas por " . $_POST["nome"] . ":</h3>";
    
    $ano_atual = (int)date("Y");

    for($i=$ano_atual;$i>=($ano_atual-$idade+5);$i--){
        if($i%4!=0 && $i%2==0 && $i>=1930){
            echo "<br /> $i - " .$copa[$i];
        }
    }

    

    echo "<hr />";
}

?>